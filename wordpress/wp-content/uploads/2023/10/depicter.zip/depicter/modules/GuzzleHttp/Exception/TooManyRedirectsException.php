<?php

namespace Depicter\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}

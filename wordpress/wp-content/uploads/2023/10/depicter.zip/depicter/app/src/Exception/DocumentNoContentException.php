<?php
namespace Depicter\Exception;

class DocumentNoContentException extends EntityException {}

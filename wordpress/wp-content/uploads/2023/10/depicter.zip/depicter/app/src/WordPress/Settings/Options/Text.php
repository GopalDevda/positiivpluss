<?php

namespace Depicter\WordPress\Settings\Options;

use Depicter\WordPress\Settings\Options\OptionAbstract;

class Text extends OptionAbstract
{
    public $view = 'text';
}

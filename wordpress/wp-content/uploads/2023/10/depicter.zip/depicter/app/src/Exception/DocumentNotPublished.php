<?php
namespace Depicter\Exception;

class DocumentNotPublished extends EntityException {}

<?php
namespace Depicter\Document\Models\Options;

use Depicter\Document\Models\Common\States as Base;

class States extends Base
{

}

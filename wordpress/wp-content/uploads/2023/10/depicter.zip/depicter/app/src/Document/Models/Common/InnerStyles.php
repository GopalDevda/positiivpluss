<?php
namespace Depicter\Document\Models\Common;

class InnerStyles
{
	/**
	 * @var Styles
	 */
	public $items;
}

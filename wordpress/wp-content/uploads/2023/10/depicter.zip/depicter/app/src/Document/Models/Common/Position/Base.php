<?php
namespace Depicter\Document\Models\Common\Position;

class Base
{
	/**
	 * @var string
	 */
	public $origin;

	/**
	 * @var mixed
	 */
	public $x;

	/**
	 * @var mixed
	 */
	public $y;

	/**
	 * @var mixed
	 */
	public $z;
}

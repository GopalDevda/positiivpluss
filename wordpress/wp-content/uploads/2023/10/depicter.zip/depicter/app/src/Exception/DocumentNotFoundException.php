<?php
namespace Depicter\Exception;

class DocumentNotFoundException extends EntityException {}

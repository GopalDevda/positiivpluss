<?php

namespace Depicter\Modules;


class Modules{

	public function bootstrap(){}
}

<?php
namespace Depicter\Document\Models\Common;


class States
{
	/**
	 * @var mixed|null
	 */
	public $default = null;

	/**
	 * @var mixed|null
	 */
	public $tablet = null;

	/**
	 * @var mixed|null
	 */
	public $mobile = null;
}

<?php

namespace Depicter\WordPress\Settings\Options;

use Depicter\WordPress\Settings\Options\OptionAbstract;

class Textarea extends OptionAbstract
{
    public $view = 'textarea';
}

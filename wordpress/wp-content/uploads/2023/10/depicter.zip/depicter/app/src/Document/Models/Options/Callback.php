<?php
namespace Depicter\Document\Models\Options;


class Callback
{
	/**
	 * @var string
	 */
	public $type;

	/**
	 * @var string
	 */
	public $label;

	/**
	 * @var string
	 */
	public $value;
}

<?php
namespace Depicter\Document\Models\Common\Measure;


class Dimension
{
	/**
	 * @var Base
	 */
	public $width;

	/**
	 * @var Base
	 */
	public $height;

	/**
	 * @var Base
	 */
	public $depth;
}

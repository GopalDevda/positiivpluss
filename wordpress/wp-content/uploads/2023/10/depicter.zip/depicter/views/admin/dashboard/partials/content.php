<?php
/**
 * content partial view.
 *
 * @package Depicter
 */

?>
<div id="root"></div>

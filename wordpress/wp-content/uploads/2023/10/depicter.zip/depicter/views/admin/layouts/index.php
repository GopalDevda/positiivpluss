<?php
/**
 * Admin layout.
 *
 * @package Depicter
 */

?>
<div class="master-layout master-admin master-wrapper">
	<?php \Depicter::layoutContent(); ?>
</div>

<?php
/**
 * Layout: admin/editor/open/layout.php
 *
 * @package Depicter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div id="root"></div>

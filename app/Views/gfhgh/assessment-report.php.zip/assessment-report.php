<?php 
use App\Models\ActionCenterModel;

?>

<?= $this->extend('brand/layout/master-page.php') ?>
<?= $this->section('style') ?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/editors/quill/katex.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/editors/quill/monokai-sublime.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/editors/quill/quill.snow.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/forms/select/select2.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/vendors.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/forms/select/select2.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/tables/datatable/buttons.bootstrap5.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/brand/assets/app-assets/vendors/css/tables/datatable/rowGroup.bootstrap5.min.css')?>">
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap.min.js">
  <link rel="stylesheet" type="text/css" href="assets/header.css">
<style type="text/css">
  .mybg{
      background: #262626 !important;
      color: #fff !important;
      position: absolute;
      width: 100%;
      height: 57px;
  }
  .mybg h5{
      color: #fff !important;
  }
  .myimg-style{
    width: 46px;
    border-radius: 50%;
    border: 0.5px solid #defe73;
    padding: 2px
  }
  .margin-top{
    margin-top: 39px !important;
  }
  .divider .divider-text:after, .divider .divider-text:before {
    border-top: 1px solid #defe73 !important;
  }
  .divider .divider-text:after, .divider .divider-text:before {
    border-top: 1px solid #defe73 !important;
  }
  .card_body_inn_2 {
    padding: 0 1.25rem 1.25rem;
  }
  .card_body_txt.vertical_full {
    flex-direction: column;
  }
  .card_body_txt {
    display: flex;
    align-items: center;
  }
  .card_body_txt.vertical_full .q_radio_btn.vertical {
    margin-bottom: 20px;
    max-width: 100%;
    width: 100%;
  }
  .card_body_txt.cbt_2 .q_radio_btn {
      display: grid;
  }
  .card_body_txt .q_radio_btn.vertical {
      flex-direction: column;
      width: 8%;
      margin: 0 0 0 auto;
      border: none;
  }
  .card_body_txt .q_radio_btn {
      border: 2px solid #262626;
  }
  .card_body_txt .q_radio_btn {
      width: 20%;
      display: flex;
      align-items: center;
      border: 1px solid #defe73;
      border-radius: 25px;
  }
  .q_radio_btn {
      margin: 20px 0px;
  }
  .card_body_txt .q_radio_btn.vertical .radio {
      border: 2px solid #262626 !important;
  }
  .card_body_txt .q_radio_btn.vertical .radio {
      width: 100%;
      border-radius: 40px;
      margin-bottom: 10px;
      height: auto;
      overflow: hidden;
  }

  .card_body_txt .q_radio_btn .radio {
      margin-bottom: 0;
      padding-left: 0;
      height: 36px;
      width: 50%;
  }
  .card_body_txt .q_radio_btn.q_radio_first .radio span, .card_body_txt .q_radio_btn.q_radio_first .radio:first-child span {
    border-right: none !important;
 }

.card_body_txt .q_radio_btn.q_radio_first .radio:first-child span {
    border-right: 2px solid #262626 !important;
}
.card_body_txt .q_radio_btn.q_radio_first .radio:first-child span {
    border-radius: 25px 0 0 25px;
}
.card_body_txt .q_radio_btn.vertical .radio:first-child span {
    /* border-radius: 25px 25px 0 0; */
}
.card_body_txt .q_radio_btn .radio:first-child span {
    /* border-right: 2px solid #262626 !important; */
}
.card_body_txt.vertical_full .q_radio_btn .radio span {
    padding: 7px 20px;
    line-height: 20px;
    border-radius: 30px;
}
.card_body_txt .q_radio_btn .radio:first-child span {
    /* border-radius: 25px 0 0 25px; */
}
.card_body_txt .radio input:checked~span {
    background-color: #DEFE73 !important;
    color: #262626;
}
.card_body_txt .q_radio_btn .radio span {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    color: #262626;
}
.checkbox input, .radio input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
    height: 0;
    width: 0;
}
.q-detail{
    background: #262626;
    padding: 16px;
    color: #fff;
    margin-bottom: 20px;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
}
.accordion-button{
    padding: 9px 15px !important;
    background: #EDFEB6 !important;
    border: 1px solid #a4bd50 !important;
    transition: 0.5s;
}
.accordion-button:hover{
    transition: 0.5s !important;
    background: #defe73 !important;
    cursor: pointer;
}
.modal-dialog {
    max-width: 580px !important;
}
.accordion-body{
    border: 1px solid #ddd;
    border-radius: 10px;
}
</style>
<?= $this->endSection();?>

<?= $this->section('content') ?>
<div class="app-content content">

<!-- <button class="btn btn-primary" type="button" data-bs-target="#myModal1" data-bs-toggle="modal">Open First Modal</button> -->
<div class="modal fade" id="myModal1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header mybg text-white text-center d-block">
        <h5 class="modal-title">First Modal</h5>
      </div>
      <div class="divider margin-top mb-0">
            <div class="divider-text"><img src="<?php echo base_url('public/brand/assets/app-assets/images/i5.png?v=1')?>" class="myimg-style"></div>
          </div>
      <div class="modal-body">
        <div class="accordion accordion-margin" id="accordionMargin">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginOne">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginOne"
                  aria-expanded="false"
                  aria-controls="accordionMarginOne"
                >
                  Water Management
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginOne"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginOne"
                data-bs-parent="#accordionMargin">
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginTwo">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginTwo"
                  aria-expanded="false"
                  aria-controls="accordionMarginTwo"
                >
                  Water Conservation
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginTwo"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginTwo"
                data-bs-parent="#accordionMargin"
              >
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
      </div>
      <div class="modal-footer d-flex justify-content-between d-flex justify-content-between">
        <button type="button" class="btn btn-primary btn-prev">Prev</button>
        <button type="button" class="btn btn-primary btn-next">Next</button>
      </div>
    </div>
  </div>
</div>

<!-- <button class="btn btn-primary" type="button" data-bs-target="#myModal2" data-bs-toggle="modal">Open Second Modal</button> -->
<div class="modal fade" id="myModal2">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header mybg text-white text-center d-block">
        <h5 class="modal-title">Second Modal</h5>
      </div>
      <div class="divider margin-top mb-0">
            <div class="divider-text"><img src="<?php echo base_url('public/brand/assets/app-assets/images/i1.png?v=1')?>" class="myimg-style"></div>
          </div>
      <div class="modal-body">
        <div class="accordion accordion-margin" id="accordionMargin">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginOne">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginOne"
                  aria-expanded="false"
                  aria-controls="accordionMarginOne"
                >
                  Water Management
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginOne"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginOne"
                data-bs-parent="#accordionMargin"
              >
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginTwo">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginTwo"
                  aria-expanded="false"
                  aria-controls="accordionMarginTwo"
                >
                  Water Conservation
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginTwo"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginTwo"
                data-bs-parent="#accordionMargin"
              >
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
      </div>
      <div class="modal-footer d-flex justify-content-between">
        <button type="button" class="btn btn-primary btn-prev">Prev</button>
        <button type="button" class="btn btn-primary btn-next">Next</button>
      </div>
    </div>
  </div>
</div>

<!-- <button class="btn btn-primary" type="button" data-bs-target="#myModal3" data-bs-toggle="modal">Open Third Modal</button> -->
<div class="modal fade" id="myModal3">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header mybg text-white text-center d-block">
        <h5 class="modal-title">Third Modal</h5>
      </div>
      <div class="divider margin-top mb-0">
            <div class="divider-text"><img src="<?php echo base_url('public/brand/assets/app-assets/images/i2.png?v=1')?>" class="myimg-style"></div>
          </div>
      <div class="modal-body">
        <div class="accordion accordion-margin" id="accordionMargin">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginOne">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginOne"
                  aria-expanded="false"
                  aria-controls="accordionMarginOne"
                >
                  Water Management
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginOne"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginOne"
                data-bs-parent="#accordionMargin"
              >
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginTwo">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginTwo"
                  aria-expanded="false"
                  aria-controls="accordionMarginTwo"
                >
                  Water Conservation
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginTwo"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginTwo"
                data-bs-parent="#accordionMargin"
              >
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
      </div>
      <div class="modal-footer d-flex justify-content-between">
        <button type="button" class="btn btn-primary btn-prev">Prev</button>
        <button type="button" class="btn btn-primary btn-next">Next</button>
      </div>
    </div>
  </div>
</div>

<!-- <button class="btn btn-primary" type="button" data-bs-target="#myModal4" data-bs-toggle="modal">Open Four Modal</button> -->
<div class="modal fade" id="myModal4">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header mybg text-white text-center d-block">
        <h5 class="modal-title">Four Modal</h5>
      </div>
      <div class="divider margin-top mb-0">
            <div class="divider-text"><img src="<?php echo base_url('public/brand/assets/app-assets/images/i3.png?v=1')?>" class="myimg-style"></div>
          </div>
      <div class="modal-body">
        <div class="accordion accordion-margin" id="accordionMargin">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginOne">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginOne"
                  aria-expanded="false"
                  aria-controls="accordionMarginOne"
                >
                  Water Management
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginOne"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginOne"
                data-bs-parent="#accordionMargin"
              >
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingMarginTwo">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#accordionMarginTwo"
                  aria-expanded="false"
                  aria-controls="accordionMarginTwo"
                >
                  Water Conservation
                  <span class="ms-auto me-2"><i class="fa-solid fa-circle-question"></i></span>
                </button>
              </h2>
              <div
                id="accordionMarginTwo"
                class="accordion-collapse collapse"
                aria-labelledby="headingMarginTwo"
                data-bs-parent="#accordionMargin"
              >
                <div class="accordion-body p-0">
                  <div class="q-detail">
                    Pastry pudding cookie toffee bonbon jujubes jujubes powder topping. Jelly beans gummi bears sweet roll
                    bonbon muffin liquorice. Wafer lollipop sesame snaps. Brownie macaroon cookie muffin cupcake candy
                    caramels tiramisu. Oat cake chocolate cake sweet jelly-o brownie biscuit marzipan. Jujubes donut
                    marzipan chocolate bar. Jujubes sugar plum jelly beans tiramisu icing cheesecake.
                  </div>
                  <div class="card_body_inn_2">
                    <div class="card_body_txt cbt_2 vertical_full">
                        <div class="q_radio_btn q_radio_first vertical mb-0">
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="4" checked="checked">
                                <span style="border-right: 2px solid black;">No</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="95">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="96">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage and have implemented improvement policies.</span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="97">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented and have set reduction targets. </span>
                            </label>
                            <label class="radio radio-primary">
                                <input type="radio" name="answer2" value="98">
                                <span style="border-right: 2px solid black;">Yes we Regularly Monitor our usage, have improvement policies are implemented, have set reduction targets and do initiatives to conserve the local watersheds</span>
                            </label>
                        </div>
                    </div>
                    <div class="comment_optional">
                        <p class="comnt_open show_btn">Comment (Optional)</p>
                        <div class="commnt_text">
                            <textarea class="form-control" name="remark2" id="remark2" placeholder="Your comment..."></textarea>
                            <!-- <span class="comment_close">x</span> -->
                        </div>
                    </div>
                    <div class="row mt-2">
                      <div class="col-md-9 col-12">
                        <div class="mb-1">
                          <label class="form-label" for="first-name-column">Media</label>
                          <input type="file" class="form-control" name="fname-column">
                        </div>
                      </div>
                      <div class="col-md-3 col-12">
                        <div class="mb-1 float-end">
                          <label class="form-label w-100" for="last-name-column">&nbsp;</label>
                          <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#new-task-modal">Action</button>
                        </div>
                      </div>
                    </div>
                    <span id="responseDiv2" style="col2or: green;font-size: 15px;"></span>
                    <div class="admin_btn mt-2">
                        <input type="button" class="btn btn-gradient-dark btn-sm" value="Submit" onclick="saveQuestion()">
                        <input type="button"class="btn btn-gradient-dark btn-sm float-end" value="Next" onclick="getNext()">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
      <div class="modal-footer d-flex justify-content-between">
        <button type="button" class="btn btn-primary btn-prev">Prev</button>
        <button type="button" class="btn btn-primary btn-next">Next</button>
      </div>
    </div>
  </div>
</div>

   <div class="content-overlay"></div>
   <div class="header-navbar-shadow"></div>
   <div class="content-wrapper container-xxl p-0">
      <div class="content-header row">
         <div class="content-header-left col-md-12 col-12 mb-2">
            <div class="row breadcrumbs-top">
               <div class="col-12">
                  <h2 class="content-header-title float-start mb-0">Footprint Report</h2>
                  <a href='<?= base_url('Controlwork/assessment');?>' class='btn btn-primary float-end mx-2'>Back</a>
                  <div class="breadcrumb-wrapper">
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php 
         $session = session();
         if($session->get('success')){?>
      <div class="alert alert-success alert-dismissible fade show" role="alert" style="padding: 0.71rem 1rem">
         <strong>Success!</strong> <?php echo $session->get('success');?>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      <?php } ?>
      <?php 
         $session = session();
         if($session->get('error')){?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert" style="padding: 0.71rem 1rem">
         <strong>Success!</strong> <?php echo $session->get('error');?>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      <?php } ?>
      <div class="content-body">
        <!-- category_page_header -->
        <div class="category_page_header mb-2">
      <div class="cph_inner">
        <div class="cph_left">
          <img src="https://positiivplus.io/public/uploads/assessment/1629138611_2179817bd862b8f2b7ae.png">                                
        </div>
        <div class="cph_right">
          <div class="cph_title"><span>FOOTPRINT</span>&nbsp;<span class='float-end'>Complete <?= $com;?> time</span></div>
          <div class="cph_short_desc">
            This is an Advanced assessment aligning you brand wth the United Nation's Sustainable Development Goals.
          </div>
          <div class="cph_status">
            <div class="cph_status_left d-flex">
              <div class="cph_score_icon me-1">
                <img src="<?php echo base_url('public/brand/assets/app-assets/images/icon_score.png?v=1')?>">                                            
              </div>
              <div class="cph_score_content">
                <div class="cph_score_label">Question Completion</div>
                <div class="cph_score_result fw-bolder"><span id="tot_attempt_id" class="fw-bolder"><?= $Total_ques;?></span> Out of <?= $Total_ques;?></div>
              </div>
            </div>
            <div class="cph_status_right d-flex">
              <div class="cph_score_icon me-1">
                <img src="https://positiivplus.io/public/brand/assets/custom_img/icon_complete.png">
              </div>
              <div class="cph_score_content">
                <div class="cph_score_label">Utopiic Level : Dorment</div>
                <div class="cph_score_result fw-bolder"><?= $percentile1; ?>% Out of 100</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- category_page_header -->

    
        <!-- <section id="basic-horizontal-layouts">
          <div class="row">
            <div class="col-md-6 col-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Ghg(In percentage(%))</h4>
                </div>
                <div class="card-body">
                  <div id="echartBar1" style="height: 300px;"></div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Risk Assessment(In percentage(%))</h4>
                </div>
                <div class="card-body">
                  <div id="topStagePie" style="height: 300px;"></div>
                </div>
              </div>
            </div>
          </div>
        </section>
    end blocks  -->
         <!-- <section class="app-user-list"> -->
       
          <!-- <h4 class="fw-bolder">Top in each stage</h4>
          <div class="card">
            <div class="card-body card-datatable table-responsive pt-0">
              <table class="table table-bordered" id="example">
                <thead class="table-light">
                  <tr>
                    <th>S No.</th>
                    <th>Scope</th>
                    <th>Ghg</th>
                    <th>Factor</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>scope 3 </td>
                    <td>Energy</td>
                    <td>Paper bag, 30 kg capacity,</td>
                    <td><span class="badge badge-glow bg-dark">856.31 kgs CO2e</span></td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>scope 3 </td>
                    <td>Mobile Fuel </td>
                    <td>Granite</td>
                    <td><span class="badge badge-glow bg-dark">804.14 kgs CO2e</span></td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>scope 3 </td>
                    <td>Water</td>
                    <td>Copper (2)</td>
                    <td><span class="badge badge-glow bg-dark">354.00 kgs CO2e</span></td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td>scope 3 </td>
                    <td>Consumables</td>
                    <td>Paper Boards</td>
                    <td><span class="badge badge-glow bg-dark">643.58 kgs CO2e</span></td>
                  </tr>
                </tbody>
              </table>
            </div> -->
         <!--   Modal to add new user starts -->
           <!--  <div class="modal modal-slide-in new-user-modal fade" id="modals-slide-in">
              <div class="modal-dialog">
                <form class="add-new-user modal-content pt-0">
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">×</button>
                  <div class="modal-header mb-1">
                    <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
                  </div>
                  <div class="modal-body flex-grow-1">
                    <div class="mb-1">
                      <label class="form-label" for="basic-icon-default-fullname">Full Name</label>
                      <input
                      type="text"
                      class="form-control dt-full-name"
                      id="basic-icon-default-fullname"
                      placeholder="John Doe"
                      name="user-fullname"
                      />
                    </div>
                    <div class="mb-1">
                      <label class="form-label" for="basic-icon-default-uname">Username</label>
                      <input
                      type="text"
                      id="basic-icon-default-uname"
                      class="form-control dt-uname"
                      placeholder="Web Developer"
                      name="user-name"
                      />
                    </div>
                    <div class="mb-1">
                      <label class="form-label" for="basic-icon-default-email">Email</label>
                      <input
                      type="text"
                      id="basic-icon-default-email"
                      class="form-control dt-email"
                      placeholder="john.doe@example.com"
                      name="user-email"
                      />
                    </div>
                    <div class="mb-1">
                      <label class="form-label" for="basic-icon-default-contact">Contact</label>
                      <input
                      type="text"
                      id="basic-icon-default-contact"
                      class="form-control dt-contact"
                      placeholder="+1 (609) 933-44-22"
                      name="user-contact"
                      />
                    </div>
                    <div class="mb-1">
                      <label class="form-label" for="basic-icon-default-company">Company</label>
                      <input
                      type="text"
                      id="basic-icon-default-company"
                      class="form-control dt-contact"
                      placeholder="PIXINVENT"
                      name="user-company"
                      />
                    </div>
                    <div class="mb-1">
                      <label class="form-label" for="country">Country</label>
                      <select id="country" class="select2 form-select">
                        <option value="Australia">USA</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="Belarus">Belarus</option>
                        <option value="Brazil">Brazil</option>
                        <option value="Canada">Canada</option>
                        <option value="China">China</option>
                        <option value="France">France</option>
                        <option value="Germany">Germany</option>
                        <option value="India">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Japan">Japan</option>
                        <option value="Korea">Korea, Republic of</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Philippines">Philippines</option>
                        <option value="Russia">Russian Federation</option>
                        <option value="South Africa">South Africa</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="United States">United States</option>
                      </select>
                    </div>
                    <div class="mb-1">
                      <label class="form-label" for="user-role">User Role</label>
                      <select id="user-role" class="select2 form-select">
                        <option value="subscriber">Subscriber</option>
                        <option value="editor">Editor</option>
                        <option value="maintainer">Maintainer</option>
                        <option value="author">Author</option>
                        <option value="admin">Admin</option>
                      </select>
                    </div>
                    <div class="mb-2">
                      <label class="form-label" for="user-plan">Select Plan</label>
                      <select id="user-plan" class="select2 form-select">
                        <option value="basic">Basic</option>
                        <option value="enterprise">Enterprise</option>
                        <option value="company">Company</option>
                        <option value="team">Team</option>
                      </select>
                    </div>
                    <button type="submit" class="btn btn-primary me-1 data-submit">Submit</button>
                    <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                  </div>
                </form>
              </div>
            </div> -->
            <!-- Modal to add new user Ends-->
     <!--      </div> -->
          <!-- list and filter end -->
       <!--  </section> -->
     <!--  </div>
   </div> 





 
<div style="margin-top: 3%;" class="container">

        -->
<?php
$v = new ActionCenterModel();
$db = \Config\Database::connect();
        $session = session();
        $supplier_info = $session->get('supplier_info');
        $s_id = $supplier_info['supplier_id'];
$dat = $db->query("SELECT ed.* FROM `all_assessment_question` as ed  where ed.status=1")->getResultArray();
$d = $v->where('status',1)->where('status',4)->where('owner_id',$s_id)->where('assign_from','Qualitative')->findAll();
foreach ($dat as  $value) {
foreach($d as $f){
if($f['question_id'] == $value['id']){
echo $f['id'];
}
}
}
 $data['actio'] = $v->where('owner_id',$s_id)->where('assign_from','Qualitative')->countAllResults();
 // print_r($data['actio']);
 // die();
?>

    <div class="clear-fix">
      <h4>
<?php foreach($control_assessment as $row){ ?>
        <?php
             
                foreach($assessment as $dd){ 
                echo $dd['id']==$row['indicator']? $dd['assessment_name']:'';
                                
                   } ?>

        <?php   }?>
    
    </h4>

      <p style="font-weight: 100; float: left;">27 Jun 2022 / H J</p>
       <!-- <h6 style=" float: right; color: green;">Complete</h6> -->
  <input  style=" float: right; color: green;" type="button" value="Download PDF File" 
  onclick="DownloadFile('assessment-report.pdf')"/>

    </div>
         <table class="table">
  <thead>
   
  </thead>
  <tbody>
     <tr style="background:#e9ecef;">
      <th style="font-weight: 400;">Score</th>
      <td><b></b> </td>
   
      <td><b></b></td>
      <td><b><?php echo $yyyyy ?></b> Actions</td>
    </tr>
    <tr>
      <th>Site</th>
      <td><?php foreach($control_assessment as $row){ ?>
        <?php
             
                foreach($assessm as $dd){ 
                echo $dd['id']==$row['sub_boundary']? $dd['cp_name']:'';
                                
                   } ?>

        <?php   }?></td>
      <td></td>
      <!-- <td style="font-weight: 100;">vvc</td> -->
    </tr>
    <tr>
      <th>Client/Site</th>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>Conducted on (Date and Time)</th>
      <td style="font-weight: 100;">
        <?php foreach($control_assessment as $row){ ?>
       
              <?php  echo $row['created-at']; ?>
                                
                 

        <?php   }?>
      </td>
      <td></td>
      <td></td>
      
    </tr>
     <tr>
      <th>Inspected by</th>
      <td>
        <?php foreach($control_assessment as $row){ ?>
        <?php
             
                foreach($inspected as $dd){ 
                echo $dd['id']==$row['assigned_to']? $dd['supplier_name']:'';
                                
                   } ?>

        <?php   }?>
      </td>

      <td></td>
      <td style="font-weight: 100;"></td>
    </tr>
    <tr>
      <th>Created by</th>
      <td>
        <?php echo $s_name; ?>
      </td>
      <td></td>
      <td></td>
    </tr>
     <tr>
      <th>Location</th>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>


</div>
<!-- control_ass -->


<div style="background:#e9ecef;" class="container">
<table class="table">
 <tbody>
     <tr style="background:#e9ecef;">
      <th style="font-weight: bold; float: left;">
        <?php  foreach($control_ass as $show){ ?>

 <?php
       

          foreach($ind as $dd){ ?>
          
          <?php if($show['indicator'] == $dd['id']){ ?>
       
          <?php echo $dd['indicator_name']; ?> 

          <?php  } ?>    
          <?php  } ?>    

           <?php }?>


        </th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">

    <select class="form-control" name="cars" id="cars">
     
<?php if(empty($iv)){?>
  <option value="">No Action Taken!
      </option>
   <?php } 
    foreach($iv as $show){  ?>

   <?php if(empty($show['title'])){?>
  <option value="">No Action 
      </option>
   <?php } 
  else { ?>
<option value="">
      <?php echo $show['title'];?>  
      </option>

  <?php }?>

      
     

   <?php } ?> 
  </select>
      </td>
    </tr>
</tbody>
</table>
</div>

<?php $i=0; foreach($assessmentreport_data as $show){ ?>
<div  class="container c1 pt-3">
  
  <h5 class="text-dark">

    <b>
       <?php
                if(!empty($rohit)){
                    foreach($rohit as $dd){ 
                    echo $dd['id']==$show['question_id']? $dd['question_title']:'';
                                
                            
      } }?>
      </b>
        
      </h5>

<div class="box1">
      <h5>  <b><?php echo ++$i; ?></b>

<?php
      if(!empty($rohit)){
      foreach($rohit as $dd){ ?>
        <?php echo  $dd['id']==$show['question_id']? $dd['question']:''; ?>
          <?php } }?>
        </h5>
     </div>
  <div style="float: right;">
    <?php if($show['answer'] == json_encode('No')){ ?>
    <div class="box2 pt-2">
         <button class="btn btn-danger"><?php echo $show['answer']; ?></button>
     </div>
  <?php } 
 else if($show['answer'] == json_encode('Yes')){ ?>
    <div class="box2 pt-2">
         <button class="btn btn-success"><?php echo $show['answer']; ?></button>
     </div>
    <?php }

   else { ?>
    <div class="box2 pt-2">
         <button class="btn btn-primary"><?php echo $show['answer']; ?></button>
     </div>
  <?php } ?>
    
</div>
  &nbsp;

<div class="container" >

<div class="box33" style="width:50%; ">
    <h5>
     <?php if(!$show['comment'] == ''){ ?>


      Comment:- <span><?php echo $show['comment'] ?></span></h5>

<?php
} else { ?>
 <h5>
      Comment:- <span>NO Comment</span></h5>

<?php } ?>
   
</div>
<!-- 
<div class="box44" style="width:50%; float:right;">
    
  <img style="width: 30%;" src="https://thumbs.dreamstime.com/b/d-illustration-economic-growth-graph-economic-growth-graph-120024688.jpg">
</div> -->

</div>
</div>
<?php } ?>



<!-- &nbsp;
<br> -->

<!-- <div  class="container c1">
      
      <p>Clause 4 / Food Safety Management System / Documentation Requirements / Control of documents</p>
     

     <div class="box1">
      <h5>Are the documents - which are required by the food safety
management system - controlled?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>

  &nbsp; -->

<!-- <div  class="container c1">
      
      <p>Clause 4 / Food Safety Management System / Documentation Requirements / Control of documents</p>
     

     <div class="box1">
      <h5>b) To review and update as necessary and re-approve
documents?</h5> -->
     <!-- </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>

  &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 6 / Resource management / Work environment</p>
     

     <div class="box1">
      <h5>Does the organization provide the resources for the
establishment, management and maintenance of the work
environment needed to implement the requirements of ISO
22000 standard?</h5> -->
     <!-- </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>


    &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Internal audit</p>
     

     <div class="box1">
      <h5>a) Conforms to the planned arrangements, to the food safety
management system requirements established by the
organization, and to the requirements of this International
Standard?</h5> -->
   <!-- /div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div> -->


<!--  -->
<!-- <div  class="container c1"> -->
      
      <!-- <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Internal audit</p>
     

     <div class="box1">
      <h5>b) Is effectively implemented and updated?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>

  &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Internal audit</p>
     

     <div class="box1">
      <h5>Do the selection of auditors and the conduct of audits ensure
objectivity and impartiality of the audit process?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>

    &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Internal audit</p>
     

     <div class="box1">
      <h5>Does the management responsible for the area being audited
to ensure that actions are taken without undue delay to
eliminate detected nonconformities and their causes?</h5>
     </div> -->

      <!-- <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div> -->
    
  <!-- </div> -->

   <!-- &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Evaluation of
individual verification results</p>
     

     <div class="box1">
      <h5>Does the food safety team systematically evaluate the
individual results of planned verification?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>

    &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Evaluation of
individual verification results</p>
     

     <div class="box1">
      <h5>Does the organization take action to achieve the required
conformity, when verification does not demonstrate
conformity with the planned arrangements?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>


  &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Analysis of
results of verification activities</p>
     

     <div class="box1">
      <h5>Does the food safety team analyze the results of verification
activities, including the results of the internal audits and
external audits?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div> -->

<!-- &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / FSMS verification / Analysis of
results of verification activities</p>
     

     <div class="box1">
      <h5>e) To provide evidence that any corrections and corrective
actions that have been taken are effective?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div>

&nbsp; -->
<!--  -->
<!-- <div  class="container c1">
      
      <p>Clause 8 / Validation, verification, and improvement of the FSMS / Improvement / Updating the food
safety management system</p>
     

     <div class="box1">
      <h5>Does top management ensure that the food safety
management system is continually updated?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
  </div> -->

<!-- Page 4 Clause 4 -->
<!-- &nbsp;
<div style="background:#e9ecef;" class="container">
<table class="table">
 <tbody>
     <tr style="background:#e9ecef;">
      <th style="font-weight: bold; float: left;">Clause 4</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">3 flagged, 48%</td>
    </tr>
</tbody>
</table>
</div>
 -->
<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 25px; font-weight: bold; float: left;">Food Safety Management System</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">3 flagged, 48%</td>
    </tr>
</tbody>
</table>
<hr>
</div> -->


<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">General Requirements</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">70%</td>
    </tr>
</tbody>
</table>
<hr>
</div>




 &nbsp; -->
<!--  -->
<!-- <div  class="container c1">
   
     <div class="box1">
      <h5>Has the organization established, documented and
implemented an effective food safety management system in
accordance with the requirements of ISO 22000 standard?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div> -->

<!-- &nbsp; -->
<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Documentation Requirements</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">3 flagged, 33.33%</td>
    </tr>
</tbody>
</table>
<hr>
</div> -->

<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: bold; float: left;">General</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">1 flagged, 66.67%</td>
    </tr>
</tbody>
</table>
<hr>
</div>
 -->
<!--Ques1-->

<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Does the FSMS documentation include:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div  class="container c1">
   
     <div class="box1">
        <h5>a) Documented statements of a food safety policy and related objectives?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div><br>
 -->
<!-- <div  class="container c1">
   
     <div class="box1">
        <h5>b) Documented procedures and records required by ISO 22000
standard?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div><br>

<div  class="container c1">
   
     <div class="box1">
        <h5>c) Documents needed by the organization to ensure the
effective development, implementation and updating of the
food safety management system?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
</div><br>

<div class="container" >

<div class="box33" style="width:50%; float:left;">
    <h5>Comment:- <span>This is a demo comment</span></h5>
</div>

<div class="box44" style="width:50%; float:right;">
    
  <img style="width: 30%;" src="https://thumbs.dreamstime.com/b/d-illustration-economic-growth-graph-economic-growth-graph-120024688.jpg">
</div>


</div> -->

<!--End Ques1-->

<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: 700; float: left;">Control of documents</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">2 flagged, 33.33%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Are the documents - which are required by the food safety
management system - controlled?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Do the established controls ensure that all proposed changes
are reviewed prior to implementation to determine their
effects on food safety and their impact on the food safety
management system?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>


&nbsp; -->


<!-- Ques2-->

<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Does a documented procedure exist to define the controls needed:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div  class="container c1">
   
     <div class="box1">
        <h5>a) To approve documents for adequacy prior to issue?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div><br>

<div  class="container c1">
   
     <div class="box1">
        <h5>b) To review and update as necessary and re-approve
documents?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
</div><br>

<div  class="container c1">
   
     <div class="box1">
        <h5>c) To ensure that changes and the current revision status of
documents are identified?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>


<div  class="container c1">
   
     <div class="box1">
        <h5>d) To ensure that relevant versions of applicable documents
are available at points of use?</h5>
     </div>

     
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>e) To ensure that documents remain legible and readily
identifiable?</h5>
     </div>

     
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>f) To ensure that relevant documents of external origin are
identified and their distribution controlled?</h5>
     </div>

     
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>g) To prevent the unintended use of obsolete documents, and
to apply suitable identification to them if they are retained for
any purpose?</h5>
     </div>
</div> -->
<!-- &nbsp;<div class="container" >

<div class="box33" style="width:50%; float:left;">
    <h5>Comment:- <span>This is a demo comment</span></h5>
</div>

<div class="box44" style="width:50%; float:right;">
    
  <img style="width: 30%;" src="https://thumbs.dreamstime.com/b/d-illustration-economic-growth-graph-economic-growth-graph-120024688.jpg">
</div> -->
<!--  -->


<!-- </div> -->

<!--End Ques2-->

<!-- &nbsp;
<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Please proceed to Section 5.</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>
 -->

<!--  Clause 5 -->
<!-- &nbsp;
<div style="background:#e9ecef;" class="container">
<table class="table">
 <tbody>
     <tr style="background:#e9ecef;">
      <th style="font-weight: bold; float: left;">Clause 5</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">12.7%</td>
    </tr>
</tbody>
</table>
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 25px; font-weight: bold; float: left;">Management responsibility</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">12.7%</td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Management commitment</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">50%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Is top management able to provide evidence of its
commitment to the development and implementation of the
food safety management system?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
</div> -->

<!--Ques3-->
<!-- &nbsp;
<div class=" container">
<table >
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Is top management able to provide evidence that the effectiveness of the food safety management
system is continually improved by:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>a) Showing food safety is supported by the business objectives
of the organization?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>

<div  class="container c1"> -->
   
     <!-- div class="box1">
        <h5>b) Communicating to the organization the importance of
meeting the requirements of ISO 22000 standard, any relevant
statutory and regulatory requirements, as well as customer
requirements relating to food safety?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>c) Establishing the food safety policy?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>d) Conducting management reviews?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
</div>

<div  class="container c1">
    -->
     <!-- <div class="box1">
        <h5>e) Ensuring the availability of resources?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div> -->
    
<!-- </div>


&nbsp;<div class="container" >

<div class="box33" style="width:50%; float:left;">
    <h5>Comment:- <span>This is a demo comment</span></h5>
</div>

<div class="box44" style="width:50%; float:right;">
    
  <img style="width: 30%;" src="https://thumbs.dreamstime.com/b/d-illustration-economic-growth-graph-economic-growth-graph-120024688.jpg">
</div>


</div> -->

<!--Ques3-->

<!-- &nbsp;
<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Food safety policy</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">71.43%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Has top management defined, documented and
communicated its food safety policy?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>
 -->

<!--Ques4-->
<!-- &nbsp;
<div class=" container">
<table >
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Does top management ensure that the food safety policy:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>a) Is appropriate to the role of the organization in the food
chain?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>
 -->
<!-- <div  class="container c1">
   
     <div class="box1">
        <h5>b) Conforms with both statutory and regulatory requirements
and with mutually agreed food safety requirements of
customers?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div> -->

<!-- <div  class="container c1">
   
     <div class="box1">
        <h5>c) Is communicated, implemented and maintained at all levels
of the organization?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div> -->

<!-- <div  class="container c1">
   
     <div class="box1">
        <h5>d) Is reviewed for continued suitability?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>e) Adequately addresses communication?</h5>
     </div>

    
    
</div> -->

<!-- <div  class="container c1">
   
     <div class="box1">
        <h5>f) Is supported by measurable objectives?</h5>
     </div>

      
</div> -->


<!-- &nbsp;<div class="container" >

<div class="box33" style="width:50%; float:left;">
    <h5>Comment:- <span>This is a demo comment</span></h5>
</div>

<div class="box44" style="width:50%; float:right;">
    
  <img style="width: 30%;" src="https://thumbs.dreamstime.com/b/d-illustration-economic-growth-graph-economic-growth-graph-120024688.jpg">
</div>
 -->

<!-- </div> -->

<!--Ques4-->




<!-- <div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Food safety management system planning</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div> -->

<!--Ques4-->

<!-- <div class=" container">
<table >
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Does top management ensure that:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>a) The planning of the food safety management system is
carried out to meet the requirements in clause 4.1, as well as
the objectives of the organization that support food safety?</h5>
     </div>

      <div class="box2">
        
     </div>
    
</div> -->

<!-- <div  class="container c1">
   
     <div class="box1">
        <h5>b) The integrity of the food safety management system is
maintained when changes to the food safety management
system are planned and implemented?</h5>
     </div>

      <div class="box2">
        
     </div>
    
</div> -->


<!-- &nbsp;<div class="container" >

<div class="box33" style="width:50%; float:left;">
    <h5>Comment:- <span>This is a demo comment</span></h5>
</div>

<div class="box44" style="width:50%; float:right;">
    
  <img style="width: 30%;" src="https://thumbs.dreamstime.com/b/d-illustration-economic-growth-graph-economic-growth-graph-120024688.jpg">
</div>


</div> -->

<!--End Ques4-->


<!-- <

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Food safety team leader</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>
 -->

<!--Ques5-->
<!-- <div class=" container">
<table >
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Has top management appointed a food safety team leader who, irrespective of other
responsibilities, shall have responsibility and authority:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>a) To manage a food safety team and organize its work?</h5>
     </div>

 
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>b) To ensure relevant training and education of the food
safety team member?</h5>
     </div>

</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>c) To ensure that the food safety management system is
established, implemented, maintained and updated?</h5>
     </div>

</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>d) To report to the organization's top management on the
effectiveness and suitability of the food safety management
system?</h5>
     </div>

    
</div>


&nbsp;<div class="container" >

<div class="box33" style="width:50%; float:left;">
    <h5>Comment:- <span>This is a demo comment</span></h5>
</div>

<div class="box44" style="width:50%; float:right;">
    
  <img style="width: 30%;" src="https://thumbs.dreamstime.com/b/d-illustration-economic-growth-graph-economic-growth-graph-120024688.jpg">
</div>


</div>
 -->
<!--End Ques5-->

<!-- <div class=" container">
<table >
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">NOTE: The responsibility of the food safety team leader may include liaison with external parties on
matters relating to the food safety management system.</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 25px; font-weight: bold; float: left;">Communication</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">External communication</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div class=" container">
<table >
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Has the organization established, implemented and maintained effective arrangements for
communicating with:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div  class="container c1">
   
     <div class="box1">
        <h5>a) Suppliers and contractors?</h5>
     </div>

      <div class="box2">
        
     </div>
    
</div>

&nbsp;
<div  class="container c1">
   
     <div class="box1">
        <h5>Does such communication provide information on food safety
aspects (especially to known food safety hazards that need to
be controlled by other organizations in the food chain) of the
organization's products that may be relevant to other
organizations in the food chain?</h5>
     </div>

      <div class="box2">
        
     </div>
    
</div>


<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Internal communication</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>


&nbsp;
<div  class="container c1">
   
     <div class="box1">
        <h5>Has the organization established, implemented and
maintained effective arrangements for communicating with
personnel on issues having an impact on food safety?</h5>
     </div>

      <div class="box2">
       
     </div>
    
</div>

&nbsp;
<div class=" container">
<table>
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Has the organization ensured that the food safety team is informed in a timely manner of changes,
including but not limited to the following:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>a) Products or new products?</h5>
     </div>

      <div class="box2">
       
     </div>
    
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Emergency preparedness and response</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Has top management established, implemented and
maintained procedures to manage potential emergency
situations and accidents that can impact food safety and
which are relevant to the role of the organization in the food
chain?</h5>
     </div>

      <div class="box2">
       
     </div>
    
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Management review</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">General</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Does top management review the organization’s food safety
management system, at planned intervals, to ensure its
continuing suitability, adequacy and effectiveness?</h5>
     </div>

      <div class="box2">
       
     </div>
    
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Please proceed to Section 6.</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>
 -->

<!--  Clause 5 -->
<!-- &nbsp;
<div style="background:#e9ecef;" class="container">
<table class="table">
 <tbody>
     <tr style="background:#e9ecef;">
      <th style="font-weight: bold; float: left;">Clause 6</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">1 flagged, 16.67%</td>
    </tr>
</tbody>
</table>
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 25px; font-weight: bold; float: left;">Resource management</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">1 flagged, 16.67%</td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Provision of resources</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">100%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Does the organization provide adequate resources for the
establishment, implementation, maintenance and updating of
the food safety management system?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Human resources</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">General</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Are the food safety team and the other personnel carrying out
activities having an impact on food safety, competent on the
basis of appropriate education, training, skills and
experience?</h5>
     </div>

      <div class="box2">
       
     </div>
    
</div>


<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Competence, awareness and training</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div class=" container">
<table >
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Does the organization:</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>


<div  class="container c1">
   
     <div class="box1">
        <h5>a) Identify the necessary competencies for personnel whose
activities have an impact on food safety?</h5>
     </div>

</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>b) Provide training or take other action to ensure personnel
have the necessary competencies?</h5>
     </div>

</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>c) Ensure that personnel responsible for monitoring,
corrections and corrective actions of the food safety
management system are trained?</h5>
     </div>

</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>d) Evaluate the implementation and the effectiveness of the
actions taken in a), b) and c)?</h5>
     </div>

</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>e) Ensure that the personnel are aware of the relevance and
importance of their individual activities in contributing to
food safety?</h5>
     </div>

</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>f) Ensure that the requirement for effective communication is
understood by all personnel whose activities have an impact
on food safety?</h5>
     </div>
 </div>

<div  class="container c1">
   
     <div class="box1">
        <h5>g) Maintain appropriate records of training and actions

Powered by

12/32

described in b) and c)?</h5>
     </div>

</div>


<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Infrastructure</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">100%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Does the organization provide the resources for the
establishment and maintenance of the infrastructure needed
to implement the requirements of ISO 22000 standard?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="Yes" class="btn btn-success btn-block">
     </div>
    
</div>



<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 20px; font-weight: bold; float: left;">Work environment</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;">1 flagged, 0%</td>
    </tr>
</tbody>
</table>
<hr>
</div>

<div  class="container c1">
   
     <div class="box1">
        <h5>Does the organization provide the resources for the
establishment, management and maintenance of the work
environment needed to implement the requirements of ISO
22000 standard?</h5>
     </div>

      <div class="box2">
         <input type="submit" value="No" class="btn btn-danger btn-block">
     </div>
    
</div>

 -->

<!--<div class=" container">
<table class="table">
 <tbody>
     <tr>
      <th style="font-size: 15px; font-weight: 100; float: left;">Please proceed to Section 7.</th>
      <td></td>
      <td></td>
      <td style="font-weight: 100; float: right;"></td>
    </tr>
</tbody>
</table>
<hr>
</div>-->


<?= $this->endSection(); ?>

<?= $this->section('script') ?>
<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/forms/select/select2.full.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/dataTables.bootstrap5.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/responsive.bootstrap5.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/jszip.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/pdfmake.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/vfs_fonts.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/buttons.html5.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/buttons.print.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/tables/datatable/dataTables.rowGroup.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/forms/validation/jquery.validate.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/forms/cleave/cleave.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/forms/cleave/addons/cleave-phone.us.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/editors/quill/katex.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/editors/quill/highlight.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/app-assets/vendors/js/editors/quill/quill.min.js')?>"></script>
<script src="<?php echo base_url('public/brand/assets/assets/js/echarts.min.js')?>"></script>
<!-- barchart script-->
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script>
$(document).ready(function () {
   $('[data-toggle="tooltip"]').tooltip();

   var echartElemBar = document.getElementById("echartBar1");

   if (echartElemBar) {
      var echartBar = echarts.init(echartElemBar);
      echartBar.setOption({
         legend: {
            borderRadius: 0,
            orient: "horizontal",
            x: "right",
            data: ["CO2e"],
         },
         grid: {
            left: "8px",
            right: "8px",
            bottom: "0",
            containLabel: true,
         },
         tooltip: {
            show: true,
            backgroundColor: "rgba(0, 0, 0, .8)",
         },
         xAxis: [{
            type: "category",
            data: [
               "Energy",
               "Water",
               "Consumables",
               "Mobile Fuel",
            ],
            axisTick: {
               alignWithLabel: true,
            },
            splitLine: {
               show: false,
            },
            axisLine: {
               show: true,
            },
         }, ],
         yAxis: [{
            type: "value",
            axisLabel: {
               formatter: "{value}",
            },
            min: 0,
            max: 100,
            interval: 25,
            axisLine: {
               show: false,
            },
            splitLine: {
               show: true,
               interval: "auto",
            },
         }, ],
         series: [{
            name: "CO2e",
            data: [
               45,
               82,
               35,
               93,
               71,
               89,
               49,
               91,
               80,
               86,
               35,
               40,
            ],
            label: {
               show: false,
               color: "#639",
            },
            type: "bar",
            color: "#defe73",
            smooth: true,
            itemStyle: {
               emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowOffsetY: -2,
                  shadowColor: "rgba(0, 0, 0, 0.3)",
               },
            },
         }, ],
      });
      $(window).on("resize", function () {
         setTimeout(function () {
            echartBar.resize();
         }, 500);
      });
   } // Chart in Dashboard version 1

});

var topStageElemPie = document.getElementById("topStagePie");
if (topStageElemPie) {
   //console.log(topStageElemPie);
   var topStagePie = echarts.init(topStageElemPie);
   topStagePie.setOption({
      color: ["#defe73", "#999A99", "#575757"],
      tooltip: {
         show: true,
         backgroundColor: "black",
      },
      series: [
         {
            name: "ESG Overview",
            type: "pie",
            radius: "55%",
            center: ["50%", "50%"],
            data: [{value:37.23088027237446,name:"Environment  "},{value:45.204043483009706,name:"Social"},{value:17.565076244615838,name:"Governance"}] ,
            itemStyle : {
               emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: "rgba(0, 0, 0, 0.5)",
               },
            },
         },
      ],
   });


   $(window).on("resize", function () {
      setTimeout(function () {
         topStagePie.resize();
      }, 500);
   });
}

</script>
<script type="text/javascript">
        function DownloadFile(fileName) {
            //Set the File URL.
            var url = "Files/" + fileName;
 
            //Create XMLHTTP Request.
            var req = new XMLHttpRequest();
            req.open("GET", url, true);
            req.responseType = "blob";
            req.onload = function () {
                //Convert the Byte Data to BLOB object.
                var blob = new Blob([req.response], { type: "application/octetstream" });
 
                //Check the Browser type and download the File.
                var isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    var url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.setAttribute("download", fileName);
                    a.setAttribute("href", link);
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                }
            };
            req.send();
        };
    </script>
<!-- end barchart script -->
<script>
        $("div[id^='myModal']").each(function(){
          var currentModal = $(this);
          currentModal.find('.btn-next').click(function(){
            currentModal.modal('hide');
            currentModal.closest("div[id^='myModal']").one('hidden.bs.modal', function (e) {
              $(this).nextAll("div[id^='myModal']").first().modal('show');
            })
          });
          //PREV
          currentModal.find('.btn-prev').click(function(){
            currentModal.modal('hide');
            currentModal.closest("div[id^='myModal']").one('hidden.bs.modal', function (e) {
              $(this).prevAll("div[id^='myModal']").first().modal('show');
            })
          });
        });
</script>
<!-- END: Page Vendor JS-->
<!-- END: Page Vendor JS-->
<?= $this->endSection() ?>


